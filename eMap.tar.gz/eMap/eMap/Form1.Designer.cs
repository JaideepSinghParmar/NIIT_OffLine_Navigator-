﻿namespace eMap
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label72 = new System.Windows.Forms.Label();
            this.button20 = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.nitmain___Copy;
            this.panel1.Controls.Add(this.label74);
            this.panel1.Controls.Add(this.label73);
            this.panel1.Controls.Add(this.label72);
            this.panel1.Controls.Add(this.button20);
            this.panel1.Controls.Add(this.comboBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label71);
            this.panel1.Controls.Add(this.label70);
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.label69);
            this.panel1.Controls.Add(this.label68);
            this.panel1.Controls.Add(this.label67);
            this.panel1.Controls.Add(this.label66);
            this.panel1.Controls.Add(this.label65);
            this.panel1.Controls.Add(this.label64);
            this.panel1.Controls.Add(this.label63);
            this.panel1.Controls.Add(this.label62);
            this.panel1.Controls.Add(this.label61);
            this.panel1.Controls.Add(this.label60);
            this.panel1.Controls.Add(this.label59);
            this.panel1.Controls.Add(this.label58);
            this.panel1.Controls.Add(this.label57);
            this.panel1.Controls.Add(this.label56);
            this.panel1.Controls.Add(this.label55);
            this.panel1.Controls.Add(this.label54);
            this.panel1.Controls.Add(this.label53);
            this.panel1.Controls.Add(this.label52);
            this.panel1.Controls.Add(this.label51);
            this.panel1.Controls.Add(this.label50);
            this.panel1.Controls.Add(this.label49);
            this.panel1.Controls.Add(this.label48);
            this.panel1.Controls.Add(this.label47);
            this.panel1.Controls.Add(this.label46);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label43);
            this.panel1.Controls.Add(this.label42);
            this.panel1.Controls.Add(this.label41);
            this.panel1.Controls.Add(this.label40);
            this.panel1.Controls.Add(this.label39);
            this.panel1.Controls.Add(this.label38);
            this.panel1.Controls.Add(this.label37);
            this.panel1.Controls.Add(this.label36);
            this.panel1.Controls.Add(this.label35);
            this.panel1.Controls.Add(this.label34);
            this.panel1.Controls.Add(this.label33);
            this.panel1.Controls.Add(this.label32);
            this.panel1.Controls.Add(this.label31);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.label28);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1200, 1200);
            this.panel1.TabIndex = 4;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label72
            // 
            this.label72.Location = new System.Drawing.Point(448, 278);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(54, 24);
            this.label72.TabIndex = 102;
            this.label72.Text = "HKB";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label72.Click += new System.EventHandler(this.label72_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.Red;
            this.button20.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button20.Location = new System.Drawing.Point(990, 527);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(94, 23);
            this.button20.TabIndex = 101;
            this.button20.Text = "ShowAllPath";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(1030, 493);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(166, 23);
            this.comboBox3.TabIndex = 100;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::WindowsFormsApplication1.Properties.Resources.DestImage;
            this.pictureBox2.Location = new System.Drawing.Point(1083, 397);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(20, 33);
            this.pictureBox2.TabIndex = 99;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApplication1.Properties.Resources.SrcImage;
            this.pictureBox1.Location = new System.Drawing.Point(904, 396);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(23, 32);
            this.pictureBox1.TabIndex = 98;
            this.pictureBox1.TabStop = false;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(1102, 410);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(71, 15);
            this.label71.TabIndex = 97;
            this.label71.Text = "Destination";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(927, 410);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(47, 15);
            this.label70.TabIndex = 96;
            this.label70.Text = "Source";
            this.label70.Click += new System.EventHandler(this.label70_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(1079, 428);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 23);
            this.comboBox2.TabIndex = 95;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(891, 428);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 23);
            this.comboBox1.TabIndex = 94;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label69
            // 
            this.label69.BackColor = System.Drawing.Color.LemonChiffon;
            this.label69.Font = new System.Drawing.Font("Palatino Linotype", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(864, 232);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(324, 149);
            this.label69.TabIndex = 91;
            this.label69.Text = "NITT Offline E-Map";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label68
            // 
            this.label68.Location = new System.Drawing.Point(326, 1018);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(64, 32);
            this.label68.TabIndex = 90;
            this.label68.Text = "NITT Main Gate";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label68.Click += new System.EventHandler(this.label68_Click);
            // 
            // label67
            // 
            this.label67.Location = new System.Drawing.Point(777, 994);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(52, 25);
            this.label67.TabIndex = 89;
            this.label67.Text = "Library";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label67.Click += new System.EventHandler(this.label67_Click);
            // 
            // label66
            // 
            this.label66.Location = new System.Drawing.Point(866, 756);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(141, 90);
            this.label66.TabIndex = 88;
            this.label66.Text = "Staff Quarters";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label66.Click += new System.EventHandler(this.label66_Click);
            // 
            // label65
            // 
            this.label65.Location = new System.Drawing.Point(891, 1025);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(127, 18);
            this.label65.TabIndex = 87;
            this.label65.Text = "Fourth Street NITT";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label65.Click += new System.EventHandler(this.label65_Click);
            // 
            // label64
            // 
            this.label64.Location = new System.Drawing.Point(891, 1056);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(127, 18);
            this.label64.TabIndex = 86;
            this.label64.Text = "Third Street NITT";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label64.Click += new System.EventHandler(this.label64_Click);
            // 
            // label63
            // 
            this.label63.Location = new System.Drawing.Point(891, 1087);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(127, 18);
            this.label63.TabIndex = 85;
            this.label63.Text = "Second Street NITT";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label63.Click += new System.EventHandler(this.label63_Click);
            // 
            // label62
            // 
            this.label62.Location = new System.Drawing.Point(899, 1118);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(119, 18);
            this.label62.TabIndex = 84;
            this.label62.Text = "First Street NITT";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label62.Click += new System.EventHandler(this.label62_Click);
            // 
            // label61
            // 
            this.label61.Location = new System.Drawing.Point(548, 1090);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(52, 32);
            this.label61.TabIndex = 83;
            this.label61.Text = "SAC";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label61.Click += new System.EventHandler(this.label61_Click);
            // 
            // label60
            // 
            this.label60.Location = new System.Drawing.Point(67, 797);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(90, 32);
            this.label60.TabIndex = 82;
            this.label60.Text = "PG Lecture Hall";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label60.Click += new System.EventHandler(this.label60_Click);
            // 
            // label59
            // 
            this.label59.Location = new System.Drawing.Point(2, 717);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(76, 32);
            this.label59.TabIndex = 81;
            this.label59.Text = "Architecture Dept";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label59.Click += new System.EventHandler(this.label59_Click);
            // 
            // label58
            // 
            this.label58.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(1076, 918);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(122, 88);
            this.label58.TabIndex = 80;
            this.label58.Text = "OPAL";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label58.Click += new System.EventHandler(this.label58_Click);
            // 
            // label57
            // 
            this.label57.Location = new System.Drawing.Point(736, 1092);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(57, 32);
            this.label57.TabIndex = 79;
            this.label57.Text = "Hockey Ground";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label57.Click += new System.EventHandler(this.label57_Click);
            // 
            // label56
            // 
            this.label56.Location = new System.Drawing.Point(698, 1028);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(67, 32);
            this.label56.TabIndex = 78;
            this.label56.Text = "Basketball Ground";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label56.Click += new System.EventHandler(this.label56_Click);
            // 
            // label55
            // 
            this.label55.Location = new System.Drawing.Point(564, 1036);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(52, 32);
            this.label55.TabIndex = 77;
            this.label55.Text = "Football Ground";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label55.Click += new System.EventHandler(this.label55_Click);
            // 
            // label54
            // 
            this.label54.Location = new System.Drawing.Point(550, 945);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(64, 32);
            this.label54.TabIndex = 76;
            this.label54.Text = "Volleyball Court";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label54.Click += new System.EventHandler(this.label54_Click);
            // 
            // label53
            // 
            this.label53.Location = new System.Drawing.Point(466, 1014);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(49, 32);
            this.label53.TabIndex = 75;
            this.label53.Text = "NSO Ground";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label53.Click += new System.EventHandler(this.label53_Click);
            // 
            // label52
            // 
            this.label52.Location = new System.Drawing.Point(382, 783);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(41, 32);
            this.label52.TabIndex = 74;
            this.label52.Text = "SBI ATM";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label52.Click += new System.EventHandler(this.label52_Click);
            // 
            // label51
            // 
            this.label51.Location = new System.Drawing.Point(447, 829);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(64, 29);
            this.label51.TabIndex = 73;
            this.label51.Text = "EEE Audi";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label51.Click += new System.EventHandler(this.label51_Click);
            // 
            // label50
            // 
            this.label50.Location = new System.Drawing.Point(513, 825);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(75, 32);
            this.label50.TabIndex = 72;
            this.label50.Text = "TP, Mech, META";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label50.Click += new System.EventHandler(this.label50_Click);
            // 
            // label49
            // 
            this.label49.Location = new System.Drawing.Point(258, 832);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(114, 32);
            this.label49.TabIndex = 71;
            this.label49.Text = "NIT Admin Block";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label49.Click += new System.EventHandler(this.label49_Click);
            // 
            // label48
            // 
            this.label48.Location = new System.Drawing.Point(329, 796);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(34, 32);
            this.label48.TabIndex = 70;
            this.label48.Text = "Barn";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label48.Click += new System.EventHandler(this.label48_Click);
            // 
            // label47
            // 
            this.label47.Location = new System.Drawing.Point(179, 850);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(64, 32);
            this.label47.TabIndex = 69;
            this.label47.Text = "Chemical Eng Dept";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label47.Click += new System.EventHandler(this.label47_Click);
            // 
            // label46
            // 
            this.label46.Location = new System.Drawing.Point(392, 836);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(49, 32);
            this.label46.TabIndex = 68;
            this.label46.Text = "Physics Dept";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label46.Click += new System.EventHandler(this.label46_Click);
            // 
            // label45
            // 
            this.label45.Location = new System.Drawing.Point(427, 806);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(52, 18);
            this.label45.TabIndex = 67;
            this.label45.Text = "Snacky";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label45.Click += new System.EventHandler(this.label45_Click);
            // 
            // label44
            // 
            this.label44.Location = new System.Drawing.Point(767, 732);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(64, 54);
            this.label44.TabIndex = 66;
            this.label44.Text = "CSE + CA";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label44.Click += new System.EventHandler(this.label44_Click);
            // 
            // label43
            // 
            this.label43.Location = new System.Drawing.Point(677, 751);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(77, 32);
            this.label43.TabIndex = 65;
            this.label43.Text = "Lyceum";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label43.Click += new System.EventHandler(this.label43_Click);
            // 
            // label42
            // 
            this.label42.Location = new System.Drawing.Point(665, 821);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(103, 32);
            this.label42.TabIndex = 64;
            this.label42.Text = "IIM Trichy";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label42.Click += new System.EventHandler(this.label42_Click);
            // 
            // label41
            // 
            this.label41.Location = new System.Drawing.Point(445, 765);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(64, 32);
            this.label41.TabIndex = 63;
            this.label41.Text = "EMC";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label41.Click += new System.EventHandler(this.label41_Click);
            // 
            // label40
            // 
            this.label40.Location = new System.Drawing.Point(1031, 574);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(64, 32);
            this.label40.TabIndex = 62;
            this.label40.Text = "Temple 2";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label40.Click += new System.EventHandler(this.label40_Click);
            // 
            // label39
            // 
            this.label39.Location = new System.Drawing.Point(888, 672);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(95, 19);
            this.label39.TabIndex = 61;
            this.label39.Text = "Post Office";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label39.Click += new System.EventHandler(this.label39_Click);
            // 
            // label38
            // 
            this.label38.Location = new System.Drawing.Point(363, 653);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(70, 40);
            this.label38.TabIndex = 60;
            this.label38.Text = "Lecture Hall Complex";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label38.Click += new System.EventHandler(this.label38_Click);
            // 
            // label37
            // 
            this.label37.Location = new System.Drawing.Point(848, 608);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(83, 32);
            this.label37.TabIndex = 59;
            this.label37.Text = "Buhari";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label37.Click += new System.EventHandler(this.label37_Click);
            // 
            // label36
            // 
            this.label36.Location = new System.Drawing.Point(408, 505);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(64, 32);
            this.label36.TabIndex = 58;
            this.label36.Text = "Hostel Office";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label36.Click += new System.EventHandler(this.label36_Click);
            // 
            // label35
            // 
            this.label35.Location = new System.Drawing.Point(861, 648);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(95, 19);
            this.label35.TabIndex = 57;
            this.label35.Text = "SBI + ATM";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label35.Click += new System.EventHandler(this.label35_Click);
            // 
            // label34
            // 
            this.label34.Location = new System.Drawing.Point(593, 657);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(104, 32);
            this.label34.TabIndex = 56;
            this.label34.Text = "Mgmt Studies Dept";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label34.Click += new System.EventHandler(this.label34_Click);
            // 
            // label33
            // 
            this.label33.Location = new System.Drawing.Point(631, 626);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(69, 32);
            this.label33.TabIndex = 55;
            this.label33.Text = "Production Eng";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // label32
            // 
            this.label32.Location = new System.Drawing.Point(224, 732);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(87, 32);
            this.label32.TabIndex = 54;
            this.label32.Text = "CEESAT Building";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // label31
            // 
            this.label31.Location = new System.Drawing.Point(492, 726);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(64, 32);
            this.label31.TabIndex = 53;
            this.label31.Text = " Power House";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label31.Click += new System.EventHandler(this.label31_Click);
            // 
            // label30
            // 
            this.label30.Location = new System.Drawing.Point(147, 420);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(59, 49);
            this.label30.TabIndex = 52;
            this.label30.Text = "Garnet B";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label30.Click += new System.EventHandler(this.label30_Click);
            // 
            // label29
            // 
            this.label29.Location = new System.Drawing.Point(150, 493);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(59, 49);
            this.label29.TabIndex = 51;
            this.label29.Text = "Garnet A";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label29.Click += new System.EventHandler(this.label29_Click);
            // 
            // label28
            // 
            this.label28.Location = new System.Drawing.Point(465, 393);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(77, 49);
            this.label28.TabIndex = 50;
            this.label28.Text = "Diamond Hostel";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label28.Click += new System.EventHandler(this.label28_Click);
            // 
            // label27
            // 
            this.label27.Location = new System.Drawing.Point(596, 386);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(85, 44);
            this.label27.TabIndex = 49;
            this.label27.Text = "Emrald Hostel";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(738, 393);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(66, 32);
            this.label26.TabIndex = 48;
            this.label26.Text = "Jade Hostel";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(292, 493);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(83, 49);
            this.label25.TabIndex = 47;
            this.label25.Text = "Agate Hostel";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(532, 493);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(61, 20);
            this.label24.TabIndex = 46;
            this.label24.Text = "Gurunath\r\n\r\n";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(511, 521);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(89, 21);
            this.label23.TabIndex = 45;
            this.label23.Text = "Coral Hostel";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(704, 505);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(89, 32);
            this.label22.TabIndex = 44;
            this.label22.Text = "Beryl Hostel";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(367, 558);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(89, 24);
            this.label21.TabIndex = 43;
            this.label21.Text = "Avin";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(457, 629);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(64, 32);
            this.label20.TabIndex = 42;
            this.label20.Text = "Annexure";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(457, 676);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(64, 32);
            this.label19.TabIndex = 41;
            this.label19.Text = "Octagon";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(689, 299);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(89, 32);
            this.label18.TabIndex = 40;
            this.label18.Text = "Ruby Hostel";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(381, 312);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(60, 32);
            this.label17.TabIndex = 39;
            this.label17.Text = "Lapis Hostel";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(581, 210);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(90, 32);
            this.label16.TabIndex = 38;
            this.label16.Text = "Topaz Hostel";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(394, 219);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(90, 30);
            this.label15.TabIndex = 37;
            this.label15.Text = "Saphire Hostel";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(488, 151);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(74, 33);
            this.label14.TabIndex = 36;
            this.label14.Text = "Mega Mess 1";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(736, 190);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(66, 34);
            this.label13.TabIndex = 35;
            this.label13.Text = "Zircon B";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label12.Location = new System.Drawing.Point(619, 96);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 39);
            this.label12.TabIndex = 34;
            this.label12.Text = "Zircon C";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(861, 479);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 34);
            this.label11.TabIndex = 33;
            this.label11.Text = "NIT Hospital";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(488, 312);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 32);
            this.label10.TabIndex = 32;
            this.label10.Text = "Pearl Hostel";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(736, 72);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 37);
            this.label9.TabIndex = 31;
            this.label9.Text = "Zircon A";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(243, 382);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 49);
            this.label8.TabIndex = 30;
            this.label8.Text = "Garnet C";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(197, 168);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 35);
            this.label7.TabIndex = 26;
            this.label7.Text = "Mega Mess 2";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(365, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 31);
            this.label6.TabIndex = 25;
            this.label6.Text = "Amber";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(768, 666);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 18);
            this.label5.TabIndex = 24;
            this.label5.Text = "ICE Dept";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(794, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 47);
            this.label4.TabIndex = 23;
            this.label4.Text = "Aquamarine";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(378, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 15);
            this.label3.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Unicode", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1029, 428);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 18);
            this.label1.TabIndex = 20;
            this.label1.Text = "to";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Crimson;
            this.button3.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button3.Location = new System.Drawing.Point(996, 464);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(85, 23);
            this.button3.TabIndex = 4;
            this.button3.Text = "showPath";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(101, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Help";
            // 
            // label73
            // 
            this.label73.Location = new System.Drawing.Point(716, 676);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(71, 23);
            this.label73.TabIndex = 103;
            this.label73.Text = "Vasantham";
            // 
            // label74
            // 
            this.label74.Location = new System.Drawing.Point(947, 496);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(72, 20);
            this.label74.TabIndex = 104;
            this.label74.Text = "Filter By:\r\n";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1281, 710);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds;
            this.Text = "NITT Offline eMap";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Scroll += new System.Windows.Forms.ScrollEventHandler(this.refreshOnScroll);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
    }
}

